const { Router } = require('express');
const router = Router();

const anime = require('../sample.json');
console.log(anime);

router.get('/v1', (req, res) => {
    res.json(anime);
});

router.post('/v1', (req, res) => {
    const {rating, description, img, genre, type, web_state, votes, name, id, slug, episodes_num} = req.body;
    if (rating && description && img && genre && type && web_state && votes && name && id && slug && episodes_num)
    {
        const newAnime = {...req.body};
        anime.push(newAnime);
        res.json(anime);
    }
    else
    {
        res.status(500).json({error: 'Ocurrió un error.'});
    }
});

module.exports = router;