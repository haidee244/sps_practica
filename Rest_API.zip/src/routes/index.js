const { Router } = require('express');
const router = Router ();

router.get('/anime', (req, res) => {
    const data = {
        "name" : "Haideé",
        "website" : "api-sps.com"
    };
    res.json(data);
});

module.exports = router;